﻿namespace FormyPdstawy
{
    partial class DialogKolarz
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnOk = new Button();
            btnAnuluj = new Button();
            txtImie = new TextBox();
            lblImie = new Label();
            label1 = new Label();
            textBox1 = new TextBox();
            label2 = new Label();
            textBox2 = new TextBox();
            label3 = new Label();
            textBox3 = new TextBox();
            label4 = new Label();
            checkBox1 = new CheckBox();
            label5 = new Label();
            numericUpDown1 = new NumericUpDown();
            ((System.ComponentModel.ISupportInitialize)numericUpDown1).BeginInit();
            SuspendLayout();
            // 
            // btnOk
            // 
            btnOk.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            btnOk.ImageAlign = ContentAlignment.MiddleLeft;
            btnOk.ImageKey = "close.png";
            btnOk.Location = new Point(371, 683);
            btnOk.Margin = new Padding(4, 4, 4, 4);
            btnOk.Name = "btnOk";
            btnOk.Padding = new Padding(6, 0, 0, 0);
            btnOk.Size = new Size(145, 49);
            btnOk.TabIndex = 6;
            btnOk.Text = "Zapisz";
            btnOk.UseVisualStyleBackColor = true;
            // 
            // btnAnuluj
            // 
            btnAnuluj.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            btnAnuluj.ImageAlign = ContentAlignment.MiddleLeft;
            btnAnuluj.ImageKey = "close.png";
            btnAnuluj.Location = new Point(524, 683);
            btnAnuluj.Margin = new Padding(4, 4, 4, 4);
            btnAnuluj.Name = "btnAnuluj";
            btnAnuluj.Padding = new Padding(6, 0, 0, 0);
            btnAnuluj.Size = new Size(145, 49);
            btnAnuluj.TabIndex = 7;
            btnAnuluj.Text = "Anuluj";
            btnAnuluj.UseVisualStyleBackColor = true;
            // 
            // txtImie
            // 
            txtImie.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            txtImie.Location = new Point(115, 105);
            txtImie.Name = "txtImie";
            txtImie.Size = new Size(554, 29);
            txtImie.TabIndex = 8;
            // 
            // lblImie
            // 
            lblImie.AutoSize = true;
            lblImie.Location = new Point(57, 105);
            lblImie.Name = "lblImie";
            lblImie.Size = new Size(41, 21);
            lblImie.TabIndex = 9;
            lblImie.Text = "imię";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(23, 168);
            label1.Name = "label1";
            label1.Size = new Size(75, 21);
            label1.TabIndex = 11;
            label1.Text = "nazwisko";
            // 
            // textBox1
            // 
            textBox1.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            textBox1.Location = new Point(115, 165);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(554, 29);
            textBox1.TabIndex = 10;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(51, 233);
            label2.Name = "label2";
            label2.Size = new Size(47, 21);
            label2.TabIndex = 13;
            label2.Text = "team";
            // 
            // textBox2
            // 
            textBox2.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            textBox2.Location = new Point(115, 230);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(554, 29);
            textBox2.TabIndex = 12;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(49, 297);
            label3.Name = "label3";
            label3.Size = new Size(49, 21);
            label3.TabIndex = 15;
            label3.Text = "email";
            // 
            // textBox3
            // 
            textBox3.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            textBox3.Location = new Point(115, 294);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(554, 29);
            textBox3.TabIndex = 14;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(24, 356);
            label4.Name = "label4";
            label4.Size = new Size(74, 21);
            label4.TabIndex = 16;
            label4.Text = "wpisowe";
            // 
            // checkBox1
            // 
            checkBox1.AutoSize = true;
            checkBox1.Location = new Point(115, 356);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new Size(101, 25);
            checkBox1.TabIndex = 17;
            checkBox1.Text = "wpłacono";
            checkBox1.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(34, 418);
            label5.Name = "label5";
            label5.Size = new Size(64, 21);
            label5.TabIndex = 18;
            label5.Text = "ranking";
            // 
            // numericUpDown1
            // 
            numericUpDown1.Location = new Point(115, 416);
            numericUpDown1.Margin = new Padding(4, 4, 4, 4);
            numericUpDown1.Name = "numericUpDown1";
            numericUpDown1.Size = new Size(120, 29);
            numericUpDown1.TabIndex = 19;
            // 
            // DialogKolarz
            // 
            AutoScaleDimensions = new SizeF(9F, 21F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(685, 749);
            Controls.Add(numericUpDown1);
            Controls.Add(label5);
            Controls.Add(checkBox1);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(textBox3);
            Controls.Add(label2);
            Controls.Add(textBox2);
            Controls.Add(label1);
            Controls.Add(textBox1);
            Controls.Add(lblImie);
            Controls.Add(txtImie);
            Controls.Add(btnAnuluj);
            Controls.Add(btnOk);
            Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            Margin = new Padding(4, 4, 4, 4);
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "DialogKolarz";
            Text = "Kolarz";
            ((System.ComponentModel.ISupportInitialize)numericUpDown1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnOk;
        private Button btnAnuluj;
        private TextBox txtImie;
        private Label lblImie;
        private Label label1;
        private TextBox textBox1;
        private Label label2;
        private TextBox textBox2;
        private Label label3;
        private TextBox textBox3;
        private Label label4;
        private CheckBox checkBox1;
        private Label label5;
        private NumericUpDown numericUpDown1;
    }
}